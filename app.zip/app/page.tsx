import JobCard from "@/components/job-card";
import JobSearchPanel from "@/components/job-search-panel";
import { jobs } from "@/lib/data";

export default function HomePage() {
  return (
    <div className="space-y-6">
      <section className="rounded-2xl bg-white shadow-soft p-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 grid place-items-center rounded-2xl bg-blue-600 text-white font-bold">JS</div>
          <h1 className="text-2xl md:text-3xl font-semibold">JobSearch</h1>
        </div>
        <nav className="hidden md:flex items-center gap-6 text-sm">
          <a href="/" className="text-blue-600">Home</a>
          <a href="/find-jobs" className="text-gray-600 hover:text-blue-600">Find Jobs</a>
          <a href="/find-talents" className="text-gray-600 hover:text-blue-600">Find Talents</a>
          <a href="/about-us" className="text-gray-600 hover:text-blue-600">About us</a>
          <a href="/testimonials" className="text-gray-600 hover:text-blue-600">Testimonials</a>
        </nav>
        <a href="/create-job" className="btn btn-primary rounded-full">Create Jobs</a>
      </section>

      <JobSearchPanel />

      <section className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {jobs.map((job) => (
          <JobCard key={job.id} job={job} />
        ))}
      </section>
    </div>
  );
}
