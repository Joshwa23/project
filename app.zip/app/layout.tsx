import "./globals.css";
import Header from "@/components/Header";

export const metadata = {
  title: "JobSea — Job Search",
  description: "A clean job search UI built with Next.js + Tailwind",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Header />
        <main className="container py-8">{children}</main>
      </body>
    </html>
  );
}
