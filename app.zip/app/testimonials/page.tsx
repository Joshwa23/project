export const metadata = { title: "Testimonials — JobSea" };

export default function Testimonials() {
  return (
    <section className="prose max-w-none">
      <h1>Testimonials</h1>
      <p>What our users say.</p>
      <ul>
        <li>"Super clean UI and easy to deploy." — N.</li>
        <li>"Perfect for demos and interviews." — A.</li>
      </ul>
    </section>
  );
}
