export const metadata = { title: "About Us — JobSea" };

export default function AboutUs() {
  return (
    <section className="prose max-w-none">
      <h1>About Us</h1>
      <p>
        JobSea is a demo job search UI combining a modern design with a clean developer experience.
        It's built with Next.js App Router and Tailwind CSS, and designed to work as a static export.
      </p>
    </section>
  );
}
