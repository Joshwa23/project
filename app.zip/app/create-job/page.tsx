"use client";

import { useState } from "react";

interface Job {
  title: string;
  description: string;
  type: string;
  company: string;
  city: string;
  salary: string;
}

export default function CreateJob() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState("Full-time");
  const [company, setCompany] = useState("");
  const [city, setCity] = useState("Chennai");
  const [salary, setSalary] = useState("");

  const jobTypes = ["Full-time", "Part-time", "Internship"];
  const cities = ["Chennai", "Kanchipuram", "Bangalore", "Mumbai"];

  const handleCreateJob = () => {
    if (!title || !description || !company || !salary) return;

    const newJob: Job = { title, description, type, company, city, salary };
    setJobs([newJob, ...jobs]);

    setTitle("");
    setDescription("");
    setCompany("");
    setSalary("");
    setType("Full-time");
    setCity("Chennai");
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Create Job</h1>

      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <div className="grid grid-cols-1 gap-4">
          <input
            type="text"
            placeholder="Job Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="border p-2 rounded w-full"
          />

          <textarea
            placeholder="Job Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="border p-2 rounded w-full"
          />

          <input
            type="text"
            placeholder="Company Name"
            value={company}
            onChange={(e) => setCompany(e.target.value)}
            className="border p-2 rounded w-full"
          />

          <div className="grid grid-cols-3 gap-4">
            <label className="sr-only">Job Type</label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="border p-2 rounded w-full"
              title="Select Job Type"
            >
              {jobTypes.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>

            <label className="sr-only">City</label>
            <select
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="border p-2 rounded w-full"
              title="Select City"
            >
              {cities.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            <input
              type="text"
              placeholder="Salary per month"
              value={salary}
              onChange={(e) => setSalary(e.target.value)}
              className="border p-2 rounded w-full"
            />
          </div>

          <button
            onClick={handleCreateJob}
            className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
          >
            Create Job
          </button>
        </div>
      </div>

      <h2 className="text-2xl font-semibold mb-4">Job Listings</h2>
      <div className="space-y-4">
        {jobs.map((job, idx) => (
          <div
            key={idx}
            className="border p-4 rounded shadow flex justify-between items-start"
          >
            <div>
              <h3 className="font-bold text-xl">{job.title}</h3>
              <p className="text-gray-600">
                {job.company} • {job.city}
              </p>
              <p className="text-gray-600">
                {job.type} • ₹{job.salary}/month
              </p>
              <p className="mt-2">{job.description}</p>
            </div>
            <button className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
              Apply
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
